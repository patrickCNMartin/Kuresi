library(testthat)
library(Kuresi)

test_check("Kuresi")