# Kuresi
Cancer Competition R package 

## NEWS
Clean version comming soon
