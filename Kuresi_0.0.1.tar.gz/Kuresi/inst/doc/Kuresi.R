## ----setup, eval = TRUE, echo = FALSE-----------------------------------------
knitr::opts_chunk$set(warning = FALSE, message = FALSE)


## ----libs, eval = TRUE, echo  = FALSE, message = FALSE, warning = FALSE-------
library(Kuresi)

